# IMPORTANT INFORMATION

This repository is no longer maintained. The source code has been moved to Github by James Cane and will provide support. [https://github.com/sheetsync/NCalc](https://github.com/sheetsync/NCalc)
Alternatively you can use Jint which I still maintain and might be more adapted to your needs: [https://github.com/sebastienros/jint](https://github.com/sebastienros/jint)

## Project Description
NCalc is a mathematical expressions evaluator in .NET. NCalc can parse any expression and evaluate the result, including static or dynamic parameters and custom functions.

For additional information on the technique we used to create this framework please read this article: [http://www.codeproject.com/KB/recipes/sota_expression_evaluator.aspx](http://www.codeproject.com/KB/recipes/sota_expression_evaluator.aspx).

For documentation here is the table of content:
* [description](description) : overall concepts, usage and extensibility points
* [operators](operators) : available standard operators and structures
* [values](values) : authorized values like types, functions, ...
* [functions](functions) : list of already implemented functions
* [parameters](parameters) : on how to use parameters expressions

## Functionnalities
**Simple expressions**

{code:c#}
  Expression e = new Expression("2 + 3 * 5");
  Debug.Assert(17 == e.Evaluate());
{code:c#}

**Evaluates .NET data types**

{code:c#}
  Debug.Assert(123456 == new Expression("123456").Evaluate()); // integers
  Debug.Assert(new DateTime(2001, 01, 01) == new Expression("#01/01/2001#").Evaluate()); // date and times
  Debug.Assert(123.456 == new Expression("123.456").Evaluate()); // floating point numbers
  Debug.Assert(true == new Expression("true").Evaluate()); // booleans
  Debug.Assert("azerty" == new Expression("'azerty'").Evaluate()); // strings
{code:c#}

**Handles mathematical functional from System.Math**

{code:c#}
  Debug.Assert(0 == new Expression("Sin(0)").Evaluate());
  Debug.Assert(2 == new Expression("Sqrt(4)").Evaluate());
  Debug.Assert(0 == new Expression("Tan(0)").Evaluate());
{code:c#}

**Evaluates custom functions**

{code:c#}
  Expression e = new Expression("SecretOperation(3, 6)");
  e.EvaluateFunction += delegate(string name, FunctionArgs args)
      {
          if (name == "SecretOperation")
              args.Result = (int)args.Parameters[0](0).Evaluate() + (int)args.Parameters[1](1).Evaluate();
      };
  
  Debug.Assert(9 == e.Evaluate());
{code:c#}

**Handles unicode characters**

{code:c#}
  Debug.Assert("経済協力開発機構" == new Expression("'経済協力開発機構'").Evaluate());
  Debug.Assert("Hello" == new Expression(@"'\u0048\u0065\u006C\u006C\u006F'").Evaluate());
  Debug.Assert("だ" == new Expression(@"'\u3060'").Evaluate());
  Debug.Assert("\u0100" == new Expression(@"'\u0100'").Evaluate());
{code:c#}

**Define parameters, even dynamic or expressions**

{code:c#}
  Expression e = new Expression("Round(Pow([Pi](Pi), 2) + Pow([Pi2](Pi2), 2) + [X](X), 2)");

  e.Parameters["Pi2"](_Pi2_) = new Expression("Pi * [Pi](Pi)");
  e.Parameters["X"](_X_) = 10;

  e.EvaluateParameter += delegate(string name, ParameterArgs args)
    {
      if (name == "Pi")
      args.Result = 3.14;
    };

  Debug.Assert(117.07 == e.Evaluate());
{code:c#}